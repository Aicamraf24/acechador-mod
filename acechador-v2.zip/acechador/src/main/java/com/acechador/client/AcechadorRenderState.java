package com.acechador.client;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class AcechadorRenderState extends LivingEntityRenderState {
    /** 0 = camina en 2 patas, 1 = corre en 4 patas (se interpola suavemente). */
    public float runBlend;
}
