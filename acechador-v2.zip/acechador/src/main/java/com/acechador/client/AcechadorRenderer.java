package com.acechador.client;

import com.acechador.AcechadorMod;
import com.acechador.entity.AcechadorEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

/** Renderer del Acechador: modelo propio (AcechadorModel) y textura acechador_alto.png. */
public class AcechadorRenderer extends MobRenderer<AcechadorEntity, AcechadorRenderState, AcechadorModel> {

    private static final Identifier TEXTURE =
            Identifier.fromNamespaceAndPath(AcechadorMod.MOD_ID, "textures/entity/acechador_alto.png");

    public AcechadorRenderer(EntityRendererProvider.Context context) {
        super(context, new AcechadorModel(AcechadorModel.createBodyLayer().bakeRoot()), 0.6F);
    }

    @Override
    public AcechadorRenderState createRenderState() {
        return new AcechadorRenderState();
    }

    @Override
    public void extractRenderState(AcechadorEntity entity, AcechadorRenderState state, float partialTick) {
        super.extractRenderState(entity, state, partialTick);
        state.runBlend = Mth.lerp(partialTick, entity.runBlendO, entity.runBlend);
    }

    @Override
    public Identifier getTextureLocation(AcechadorRenderState state) {
        return TEXTURE;
    }
}
