package com.acechador.client;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/**
 * Modelo propio del Acechador (~4 bloques de alto, delgado, extremidades largas y flexionadas).
 *  - De pie / caminando: 2 patas, encorvado, brazos colgando.
 *  - Persiguiendo (runBlend -> 1): se echa hacia delante y corre sobre 4 patas.
 * Unidades en píxeles de modelo (16 = 1 bloque). El suelo está en y = 24.
 */
public class AcechadorModel extends EntityModel<AcechadorRenderState> {

    /** Altura de la cadera de pie (30 px) respecto al suelo => 24 - 30. */
    private static final float HIP_Y = -6F;
    private static final float HIP_STAND = 30F;
    private static final float HIP_RUN = 20F;

    private static final java.util.Map<String, int[]> UVS = new java.util.HashMap<>();
    static {
        UVS.put("torso", new int[]{0, 0});
        UVS.put("fore_r", new int[]{25, 0});
        UVS.put("fore_l", new int[]{38, 0});
        UVS.put("thigh_r", new int[]{51, 0});
        UVS.put("shin_r", new int[]{64, 0});
        UVS.put("thigh_l", new int[]{77, 0});
        UVS.put("shin_l", new int[]{90, 0});
        UVS.put("uarm_r", new int[]{103, 0});
        UVS.put("uarm_l", new int[]{0, 27});
        UVS.put("skull", new int[]{13, 27});
        UVS.put("jaw", new int[]{42, 27});
        UVS.put("foot_r", new int[]{67, 27});
        UVS.put("foot_l", new int[]{88, 27});
        UVS.put("f1_r", new int[]{109, 27});
        UVS.put("f1_l", new int[]{114, 27});
        UVS.put("neck", new int[]{0, 46});
        UVS.put("f2_r", new int[]{13, 46});
        UVS.put("f2_l", new int[]{18, 46});
        UVS.put("hand_r", new int[]{23, 46});
        UVS.put("f0_r", new int[]{38, 46});
        UVS.put("f3_r", new int[]{43, 46});
        UVS.put("hand_l", new int[]{48, 46});
        UVS.put("f0_l", new int[]{63, 46});
        UVS.put("f3_l", new int[]{68, 46});
    }

    private final ModelPart body, head, jaw;
    private final ModelPart armR, foreR, armL, foreL;
    private final ModelPart legR, shinR, footR, legL, shinL, footL;

    public AcechadorModel(ModelPart root) {
        super(root);
        this.body = root.getChild("body");
        this.head = body.getChild("head");
        this.jaw = head.getChild("jaw");
        this.armR = body.getChild("arm_r");
        this.foreR = armR.getChild("fore_r");
        this.armL = body.getChild("arm_l");
        this.foreL = armL.getChild("fore_l");
        this.legR = root.getChild("leg_r");
        this.shinR = legR.getChild("shin_r");
        this.footR = shinR.getChild("foot_r");
        this.legL = root.getChild("leg_l");
        this.shinL = legL.getChild("shin_l");
        this.footL = shinL.getChild("foot_l");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition body = root.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4F, -22F, -2F, 8F, 22F, 4F),
                PartPose.offset(0F, HIP_Y, 0F));

        PartDefinition head = body.addOrReplaceChild("head",
                CubeListBuilder.create()
                        .texOffs(0, 46).addBox(-1.5F, -4F, -1.5F, 3F, 4F, 3F)
                        .texOffs(13, 27).addBox(-3.5F, -13F, -3.5F, 7F, 9F, 7F),
                PartPose.offset(0F, -21.5F, -0.5F));

        head.addOrReplaceChild("jaw",
                CubeListBuilder.create().texOffs(42, 27).addBox(-3F, 0F, -6F, 6F, 3F, 6F),
                PartPose.offset(0F, -5F, 3F));

        // ----- brazos (largos, con codo) -----
        addArm(body, "r", -5.5F);
        addArm(body, "l", 5.5F);

        // ----- piernas (muslo + espinilla + pie) -----
        addLeg(root, "r", -2.2F);
        addLeg(root, "l", 2.2F);

        return LayerDefinition.create(mesh, 128, 128);
    }

    private static void addArm(PartDefinition body, String side, float x) {
        PartDefinition arm = body.addOrReplaceChild("arm_" + side,
                CubeListBuilder.create().texOffs(UVS.get("uarm_" + side)[0], UVS.get("uarm_" + side)[1])
                        .addBox(-1.5F, 0F, -1.5F, 3F, 15F, 3F),
                PartPose.offset(x, -20F, 0F));
        int[] f = UVS.get("fore_" + side), h = UVS.get("hand_" + side);
        int[] f0 = UVS.get("f0_" + side), f1 = UVS.get("f1_" + side), f2 = UVS.get("f2_" + side), f3 = UVS.get("f3_" + side);
        arm.addOrReplaceChild("fore_" + side,
                CubeListBuilder.create()
                        .texOffs(f[0], f[1]).addBox(-1.5F, 0F, -1.5F, 3F, 17F, 3F)
                        .texOffs(h[0], h[1]).addBox(-2F, 17F, -1.5F, 4F, 3F, 3F)
                        .texOffs(f0[0], f0[1]).addBox(-2F, 20F, -1F, 1F, 5F, 1F)
                        .texOffs(f1[0], f1[1]).addBox(-1F, 20F, -1F, 1F, 7F, 1F)
                        .texOffs(f2[0], f2[1]).addBox(0F, 20F, -1F, 1F, 6F, 1F)
                        .texOffs(f3[0], f3[1]).addBox(1F, 20F, -1F, 1F, 5F, 1F),
                PartPose.offset(0F, 15F, 0F));
    }

    private static void addLeg(PartDefinition root, String side, float x) {
        PartDefinition leg = root.addOrReplaceChild("leg_" + side,
                CubeListBuilder.create().texOffs(UVS.get("thigh_" + side)[0], UVS.get("thigh_" + side)[1])
                        .addBox(-1.5F, 0F, -1.5F, 3F, 16F, 3F),
                PartPose.offset(x, HIP_Y, 0F));
        PartDefinition shin = leg.addOrReplaceChild("shin_" + side,
                CubeListBuilder.create().texOffs(UVS.get("shin_" + side)[0], UVS.get("shin_" + side)[1])
                        .addBox(-1.5F, 0F, -1.5F, 3F, 16F, 3F),
                PartPose.offset(0F, 16F, 0F));
        shin.addOrReplaceChild("foot_" + side,
                CubeListBuilder.create().texOffs(UVS.get("foot_" + side)[0], UVS.get("foot_" + side)[1])
                        .addBox(-1.5F, -2F, -5.5F, 3F, 2F, 7F),
                PartPose.offset(0F, 16F, 0F));
    }

    @Override
    public void setupAnim(AcechadorRenderState s) {
        super.setupAnim(s);

        float b = Mth.clamp(s.runBlend, 0F, 1F);                 // 0 = camina, 1 = corre a 4 patas
        float speed = Mth.clamp(s.walkAnimationSpeed * 1.5F, 0F, 1F);
        float phase = s.walkAnimationPos * 0.55F;
        float age = s.ageInTicks;

        // altura de la cadera: baja al correr
        float hipH = Mth.lerp(b, HIP_STAND, HIP_RUN);
        float pivotY = HIP_Y + (HIP_STAND - hipH);
        body.y = pivotY;
        legR.y = pivotY;
        legL.y = pivotY;

        // torso encorvado; al correr se echa casi horizontal
        float bodyPitch = Mth.lerp(b, 0.22F + 0.03F * Mth.sin(age * 0.05F), 1.15F);
        body.xRot = bodyPitch;
        body.yRot = Mth.sin(phase) * 0.12F * speed * (1F + b);
        body.zRot = Mth.cos(phase) * 0.05F * speed;

        // cabeza torcida y caída; al correr levanta la vista hacia delante
        head.yRot = Mth.clamp(s.yRot, -70F, 70F) * Mth.DEG_TO_RAD;
        head.xRot = Mth.clamp(s.xRot, -40F, 40F) * Mth.DEG_TO_RAD + Mth.lerp(b, 0.18F, -1.0F);
        head.zRot = 0.22F + 0.05F * Mth.sin(age * 0.07F);
        jaw.xRot = Mth.lerp(b, 0.30F + 0.08F * Mth.sin(age * 0.12F), 0.85F);

        // piernas (cinemática inversa: los pies siempre tocan el suelo, con la rodilla flexionada)
        float amp = Mth.lerp(b, 0.75F, 0.70F) * speed;
        float center = Mth.lerp(b, -0.35F, -0.90F);
        float pR = phase;
        float pL = phase + Mth.PI;
        legIk(legR, shinR, footR, center + Mth.cos(pR) * amp, hipH - Math.max(0F, Mth.sin(pR)) * 7F * speed);
        legIk(legL, shinL, footL, center + Mth.cos(pL) * amp, hipH - Math.max(0F, Mth.sin(pL)) * 7F * speed);

        // brazos colgando (de pie / caminando)
        float hangR = 0.10F + Mth.cos(pL) * 0.45F * speed + 0.04F * Mth.sin(age * 0.08F);
        float hangL = 0.10F + Mth.cos(pR) * 0.45F * speed + 0.04F * Mth.sin(age * 0.08F + 1.3F);
        float hangFore = -0.85F - 0.25F * speed + 0.05F * Mth.sin(age * 0.09F);

        // brazos como patas delanteras (corriendo): las manos tocan el suelo
        float shoulderH = hipH + 20F * Mth.cos(bodyPitch);
        float qR = phase + 0.5F;
        float qL = qR + Mth.PI;
        float upR = -0.55F + Mth.cos(qR) * 0.55F * speed;        // ángulos absolutos
        float upL = -0.55F + Mth.cos(qL) * 0.55F * speed;
        float hR = shoulderH - Math.max(0F, -Mth.sin(qR)) * 7F * speed;
        float hL = shoulderH - Math.max(0F, -Mth.sin(qL)) * 7F * speed;
        float foAbsR = (float) Math.acos(Mth.clamp((hR - 15F * Mth.cos(upR)) / 27F, -1F, 1F));
        float foAbsL = (float) Math.acos(Mth.clamp((hL - 15F * Mth.cos(upL)) / 27F, -1F, 1F));

        armR.xRot = Mth.lerp(b, hangR, upR - bodyPitch);
        foreR.xRot = Mth.lerp(b, hangFore, foAbsR - upR);
        armR.zRot = Mth.lerp(b, 0.14F, 0.10F);
        armL.xRot = Mth.lerp(b, hangL, upL - bodyPitch);
        foreL.xRot = Mth.lerp(b, hangFore, foAbsL - upL);
        armL.zRot = -Mth.lerp(b, 0.14F, 0.10F);
    }

    /** Coloca muslo/espinilla/pie para que el pie quede a "h" píxeles bajo la cadera, con el pie plano. */
    private static void legIk(ModelPart thigh, ModelPart shin, ModelPart foot, float t, float h) {
        float c = Mth.clamp(h / 16F - Mth.cos(t), -1F, 1F);
        float shinAbs = (float) Math.acos(c);
        thigh.xRot = t;
        shin.xRot = shinAbs - t;
        foot.xRot = -shinAbs;
    }
}
