package com.acechador.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.Vec3;

/**
 * El Acechador:
 *  - DÍA:   te sigue a distancia, te mira fijamente y se retira si te acercas. No ataca.
 *  - NOCHE: te persigue y te ataca sin descanso.
 *  - 100 de vida. Al morir suelta 3-5 diamantes (ver data/acechador/loot_table/entities/acechador.json).
 */
public class AcechadorEntity extends Monster {

    /** De pie: 4 bloques de alto y delgado. Corriendo a 4 patas: más bajo y más ancho. */
    private static final EntityDimensions STAND_DIMS = EntityDimensions.scalable(0.7F, 4.0F).withEyeHeight(3.6F);
    private static final EntityDimensions RUN_DIMS = EntityDimensions.scalable(1.2F, 2.7F).withEyeHeight(2.3F);

    /** Solo se usa en el cliente para animar el paso de 2 patas a 4 patas. */
    public float runBlend;
    public float runBlendO;

    public AcechadorEntity(EntityType<? extends AcechadorEntity> type, Level level) {
        super(type, level);
        this.xpReward = 50;
    }

    @Override
    public EntityDimensions getDefaultDimensions(Pose pose) {
        return this.isAggressive() ? RUN_DIMS : STAND_DIMS;
    }

    @Override
    public void setAggressive(boolean aggressive) {
        boolean before = this.isAggressive();
        super.setAggressive(aggressive);
        if (before != aggressive) {
            this.refreshDimensions();
        }
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (this.level().isClientSide()) {
            this.refreshDimensions();
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide()) {
            this.runBlendO = this.runBlend;
            this.runBlend = Mth.clamp(this.runBlend + (this.isAggressive() ? 0.12F : -0.12F), 0.0F, 1.0F);
        }
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 100.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.30D)
                .add(Attributes.ATTACK_DAMAGE, 8.0D)
                .add(Attributes.FOLLOW_RANGE, 48.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.5D);
    }

    // En 26.1 desapareció Level.getDayTime() (ahora el tiempo va por "relojes").
    // Usamos isDarkOutside() de Level si existe; si no, un cálculo con el tiempo de juego.
    private static final java.lang.reflect.Method DARK_OUTSIDE = findLevelMethod("isDarkOutside");

    private static java.lang.reflect.Method findLevelMethod(String name) {
        try {
            return Level.class.getMethod(name);
        } catch (ReflectiveOperationException e) {
            return null;
        }
    }

    /** Noche = oscuro en el exterior. Si cambias la regla, hazlo solo aquí. */
    public static boolean isNight(Level level) {
        if (DARK_OUTSIDE != null) {
            try {
                return (boolean) DARK_OUTSIDE.invoke(level);
            } catch (ReflectiveOperationException | RuntimeException ignored) {
                // cae al cálculo de respaldo
            }
        }
        long t = level.getGameTime() % 24000L;
        return t >= 12500L && t < 23500L;
    }

    public static boolean checkSpawnRules(EntityType<AcechadorEntity> type, ServerLevelAccessor level,
                                          EntitySpawnReason reason, BlockPos pos, RandomSource random) {
        return Monster.checkMonsterSpawnRules(type, level, reason, pos, random);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.3D, false));
        this.goalSelector.addGoal(3, new StalkPlayerGoal(this));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 32.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));

        // Si le pegas (de día o de noche), se defiende.
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        // Solo elige objetivo automáticamente DE NOCHE.
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(
                this, Player.class, 10, true, false,
                (target, serverLevel) -> isNight(serverLevel)));
    }

    @Override
    protected void customServerAiStep(ServerLevel level) {
        super.customServerAiStep(level);
        // Al amanecer deja de perseguir (salvo que lo hayas herido tú).
        LivingEntity target = this.getTarget();
        if (target != null && !isNight(level) && this.getLastHurtByMob() != target) {
            this.setTarget(null);
        }
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.WARDEN_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.WARDEN_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.WARDEN_DEATH;
    }

    /** Comportamiento diurno: seguir al jugador a distancia, mirarlo y no dejar que se acerque. */
    static class StalkPlayerGoal extends Goal {
        private static final double TOO_FAR = 20.0D;
        private static final double TOO_CLOSE = 12.0D;

        private final PathfinderMob mob;
        private Player player;

        StalkPlayerGoal(PathfinderMob mob) {
            this.mob = mob;
        }

        @Override
        public boolean canUse() {
            if (isNight(mob.level()) || mob.getTarget() != null) return false;
            Player p = mob.level().getNearestPlayer(mob, 48.0D);
            if (p == null || p.isCreative() || p.isSpectator()) return false;
            this.player = p;
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return player != null && player.isAlive() && canUse();
        }

        @Override
        public void tick() {
            mob.getLookControl().setLookAt(player, 30.0F, 30.0F);
            double dist = mob.distanceTo(player);
            if (dist > TOO_FAR) {
                mob.getNavigation().moveTo(player, 1.0D);
            } else if (dist < TOO_CLOSE) {
                Vec3 away = DefaultRandomPos.getPosAway(mob, 16, 7, player.position());
                if (away != null) {
                    mob.getNavigation().moveTo(away.x, away.y, away.z, 1.1D);
                }
            } else {
                mob.getNavigation().stop();
            }
        }

        @Override
        public void stop() {
            mob.getNavigation().stop();
            player = null;
        }
    }
}
