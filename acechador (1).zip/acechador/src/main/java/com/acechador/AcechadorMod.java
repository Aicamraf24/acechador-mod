package com.acechador;

import com.acechador.entity.AcechadorEntity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.level.levelgen.Heightmap;

public class AcechadorMod implements ModInitializer {
    public static final String MOD_ID = "acechador";

    public static final ResourceKey<EntityType<?>> ACECHADOR_KEY = ResourceKey.create(
            Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath(MOD_ID, "acechador"));

    public static final EntityType<AcechadorEntity> ACECHADOR = Registry.register(
            BuiltInRegistries.ENTITY_TYPE,
            ACECHADOR_KEY,
            EntityType.Builder.of(AcechadorEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.95F)
                    .clientTrackingRange(10)
                    .build(ACECHADOR_KEY));

    @Override
    public void onInitialize() {
        // 100 de vida, velocidad, daño, etc.
        FabricDefaultAttributeRegistry.register(ACECHADOR, AcechadorEntity.createAttributes());

        // Puede aparecer también de día (no exige oscuridad).
        SpawnPlacements.register(ACECHADOR, SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, AcechadorEntity::checkSpawnRules);

        // Aparece de forma natural (raro) en el Overworld.
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(),
                MobCategory.MONSTER, ACECHADOR, 8, 1, 1);
    }
}
