package com.acechador.client;

import com.acechador.AcechadorMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class AcechadorClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(AcechadorMod.ACECHADOR, AcechadorRenderer::new);
    }
}
